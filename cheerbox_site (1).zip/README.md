# CheerBox

A simple static site for CheerBox – personalized 3D figurines and gift shop.

## 🚀 How to Deploy to Netlify

1. Go to https://netlify.com and log in.
2. Click **Add new site** → **Import from Git**.
3. Connect your GitHub account and select this repository.
4. Set **Build command**: (leave empty)
5. Set **Publish directory**: `/`
6. Click **Deploy Site** and you're live!

## 📁 Files

- `index.html` — Main website homepage
- `README.md` — Instructions

Made with ❤️ in Hyderabad 🇮🇳
